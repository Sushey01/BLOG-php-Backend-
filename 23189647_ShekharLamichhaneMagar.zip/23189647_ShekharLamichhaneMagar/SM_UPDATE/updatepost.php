<?php
// Include sidebar
include 'sidenav.php';

// Include your database connection file
include_once 'config.php';

// Initialize variables
$post_id = isset($_GET['id']) ? $_GET['id'] : null;
$message = '';

// Fetch post data if ID is provided
if ($post_id) {
    $sql = "SELECT * FROM posts WHERE Post_id = ?";
    $stmt = $config->prepare($sql);
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $post = $stmt->get_result()->fetch_assoc();

    if (!$post) {
        echo "<script>alert('Post not found'); window.location='adminpost.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Post ID is missing'); window.location='adminpost.php';</script>";
    exit();
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_title = $_POST['title'];
    $new_content = $_POST['content'];

    // Update post in the database
    $update_query = "UPDATE posts SET Title = ?, Content = ? WHERE Post_id = ?";
    $stmt = $config->prepare($update_query);
    $stmt->bind_param("ssi", $new_title, $new_content, $post_id);

    if ($stmt->execute()) {
        $message = "Post updated successfully.";
    } else {
        $message = "Error updating post: " . $stmt->error;
    }
}

// Close the database connection
$config->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Post</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <?php include 'sidenav.php'; ?>

    <!-- Page content -->
    <div class="content">
        <div class="container d-flex justify-content-center align-items-center min-vh-100">
            <div class="row border rounded-5 p-3 bg-white shadow box-area">
                <div class="row align-items-center">
                    <div class="header-text mb-4 text-center">
                        <h2>Update Post</h2>
                    </div>
                    <form id="postForm" class="row align-items-center" method="POST">
                        <div class="col-md-12 mb-3">
                            <label for="title" class="form-label">Post Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($post['Title']); ?>" required>
                        </div>
        
                        <div class="col-md-12 mb-3">
                            <label for="content" class="form-label">Post Content</label>
                            <textarea class="form-control" id="content" name="content" rows="5" required><?php echo htmlspecialchars($post['Content']); ?></textarea>
                        </div>
        
                        <div class="col-md-6 mx-auto mb-3">
                            <button type="submit" class="btn btn-lg btn-primary w-100 fs-6" style="background: #5271ff;">Update Post</button>
                        </div>
        
                        <input type="hidden" name="post_id" value="<?php echo htmlspecialchars($post_id); ?>">
                    </form>
                    
                    <?php if (!empty($message)) : ?>
                        <div class="alert alert-<?php echo strpos($message, 'successfully') ? 'success' : 'danger'; ?> mt-3">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
