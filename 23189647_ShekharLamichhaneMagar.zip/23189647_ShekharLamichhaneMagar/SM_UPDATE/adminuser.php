<?php
    include 'sidenav.php';
?>

<!-- Page content -->
<div class="content">
    <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <div class="row align-items-center">
            <div class="container-fluid">
                <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
                <h2 class="header-text mb-4 text-center">Manage Users</h2>
                <div class="row mt-4">
                    <div class="col-md-10">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Search for customers..." aria-label="Search for customers" aria-describedby="button-addon2">
                            <button class="btn btn-primary" type="submit" id="button-addon2" style="background: #5271ff;"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <h5 class="mb-4">Available Users:</h5>
                    <div class="col-md-12">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">SN</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    // Include your database connection file
                                    include_once 'config.php';

                                    // Fetch customers from the database
                                    $sql = "SELECT User_id, first_name, last_name, User_name, Email, Role FROM users";
                                    $result = $config->query($sql);
                                    while($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row['User_id'] .  "</td>";
                                        echo "<td>" . $row["first_name"] . "</td>";
                                        echo "<td>" . $row["last_name"] . "</td>";
                                        echo "<td>" . $row["User_name"] . "</td>";
                                        echo "<td>" . $row["Email"] . "</td>";
                                        echo "<td>" . $row["Role"] . "</td>";
                                        echo "<td>"; // Actions cell
                                        // Delete button
                                        echo "<a href='deleteuser.php?id=" . $row["User_id"] . "' class='btn btn-danger'><i class='bi bi-trash'></i> Delete</a>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }

                                    // Close the database connection
                                    $config->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
