<?php
include 'nav.php';

// Include your database connection file
include_once 'config.php';

?>

<!-- Page content -->
<div class="container-fluid mt-4">
    <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <div class="container">
            <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
            <h2 class="header-text mb-4 text-center">Category-wise Posts</h2>
            <div class="row mt-4">
                <div class="col-md-12">
                    <?php
                    // Fetch all categories
                    $categories_query = "SELECT * FROM categories";
                    $categories_result = $config->query($categories_query);

                    if ($categories_result->num_rows > 0) {
                        while ($category = $categories_result->fetch_assoc()) {
                            $category_id = $category['Category_id'];
                            $category_name = htmlspecialchars($category['Category_name']);

                            echo "<div class='mb-4'>";
                            echo "<h4>" . $category_name . "</h4>";

                            // Fetch posts for the current category
                            $posts_query = "SELECT * FROM posts WHERE Category_id = ?";
                            $stmt_posts = $config->prepare($posts_query);
                            $stmt_posts->bind_param("i", $category_id);

                            if ($stmt_posts->execute()) {
                                $posts_result = $stmt_posts->get_result();

                                if ($posts_result->num_rows > 0) {
                                    echo "<ul class='list-group'>";
                                    while ($post = $posts_result->fetch_assoc()) {
                                        echo "<li class='list-group-item'>";
                                        echo "<strong>" . htmlspecialchars($post['Title']) . "</strong><br>";
                                        echo htmlspecialchars($post['Content']);
                                        echo "</li>";
                                    }
                                    echo "</ul>";
                                } else {
                                    echo "<p>No posts found in this category</p>";
                                }
                            } else {
                                echo "<p>Error fetching posts: " . $stmt_posts->error . "</p>";
                            }

                            echo "</div>";
                        }

                        // Close statement
                        $stmt_posts->close();
                    } else {
                        echo "<p>No categories found</p>";
                    }

                    // Close the database connection
                    $config->close();
                    ?>

                    <!-- Button to Add Post -->
                    <div class="text-center mt-4">
                        <a href="useraddpost.php" class="btn btn-primary">Create Post</a>
                        <a href="userdeletepost.php" class="btn btn-danger">Delete Post</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
