<footer class="footer">
  	 <div class="container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4 class="Connect">Let's Connect</h4>
  	 			<div class="social-links">
  	 				<a href="https://www.facebook.com/shekhar.magar.77398/"><i class="bi bi-facebook"></i></a>
  	 				<a href="https://www.linkedin.com/in/magar-shekhar13/"><i class="bi bi-linkedin"></i></a>
  	 				<a href="https://www.instagram.com/sus.n_._._.mgr/"><i class="bi bi-instagram"></i></a>
  	 				<a href="https://github.com/Sushey01"><i class="bi bi-github"></i></a>
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
	   <div class="container">
        <div class="text-center py-3">
            <span class="text-muted">Copyright &copy; <?php echo date('Y'); ?> Blog</span>
        </div>
    </div>
  </footer>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>