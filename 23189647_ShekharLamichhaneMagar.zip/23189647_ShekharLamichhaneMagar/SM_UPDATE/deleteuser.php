<?php
// Include database connection
include_once 'config.php';

// Check if user ID is provided in the URL
if(isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Prepare SQL statement to delete the user
    $delete_user_sql = "DELETE FROM users WHERE User_id = ? LIMIT 1";

    // Use prepared statement for deletion
    $stmt = $config->prepare($delete_user_sql);
    $stmt->bind_param("i", $user_id);

    // Attempt to execute the prepared statement
    if ($stmt->execute()) {
        // Debug message for successful deletion
        echo "User with ID $user_id deleted successfully.";

        // Redirect to adminuser.php after successful deletion
        header("location: adminuser.php");
        exit();
    } else {
        // Display an error message if deletion fails
        echo "Error deleting user: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
} else {
    // Redirect to adminuser.php if user ID is not provided
    header("location: adminuser.php");
    exit();
}

// Close database connection
$config->close();
?>
