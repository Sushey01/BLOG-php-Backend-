-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2024 at 08:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `23189647`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Category_id` int(11) NOT NULL,
  `Category_name` varchar(60) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Category_Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Category_id`, `Category_name`, `Status`, `Category_Description`) VALUES
(0, 'Saturday', '', 'sabat ko din'),
(0, 'Daily Updates', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `Post_id` int(11) NOT NULL,
  `Category_name` int(11) DEFAULT NULL,
  `User_id` int(11) DEFAULT NULL,
  `Title` varchar(50) NOT NULL,
  `Content` varchar(45) NOT NULL,
  `Post_name` varchar(255) NOT NULL,
  `Date` text DEFAULT NULL,
  `Post_Image` int(11) DEFAULT NULL,
  `Category_id` int(11) DEFAULT NULL,
  `Category_Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`Post_id`, `Category_name`, `User_id`, `Title`, `Content`, `Post_name`, `Date`, `Post_Image`, `Category_id`, `Category_Description`) VALUES
(12, NULL, NULL, 'Struggling with PhP', 'huhuh', '', '2024-06-22 22:55:53', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `User_name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Role` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_id`, `first_name`, `last_name`, `User_name`, `Email`, `Role`, `Password`, `Created_at`) VALUES
(1, 'shekhar', 'magar', 'sus0', 'shekhar@gmail.com', '1', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '2024-06-21 18:26:50'),
(3, 'pari', 'rai', 'pari', 'rai@gmail.com', 'user', '$2y$10$CGK7fmdCz2LbvbCZjHM5rORUBCIzBtAi64/pV/be0FYLFNojMdkAe', '2024-06-21 18:41:33'),
(4, 'shekhar Lamichhane', 'magar', 'shekhu1', 'susmagar012@gmail.com', 'user', '$2y$10$v4VjwzlHA2XpuLsEH5MYwOrj38N4u96y7Urw5JS1EyB8U7FjsokEm', '2024-06-22 11:47:16'),
(5, 'ball', 'kun', 'knight', 'ball@gmail.com', 'user', '$2y$10$eO9RUzDZvnHxCiyKuI7msOKkrJWOEUmm03jlq92dcjIMBpYzbyvKW', '2024-06-22 11:53:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`Post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `Post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
