<?php
// Include database connection
include_once 'config.php';

// Check if user ID and category ID are provided in the URL
if(isset($_GET['user_id']) && isset($_GET['category_id'])) {
    $user_id = $_GET['user_id'];
    $category_id = $_GET['category_id'];

    // Prepare SQL statement to delete posts for the specific user in the specific category
    $sql = "DELETE FROM posts WHERE User_id = ? AND Category_id = ?";

    if ($stmt = $config->prepare($sql)) {
        // Bind the parameters
        $stmt->bind_param("ii", $user_id, $category_id);

        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            // Success message
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Posts for the user in the specific category deleted successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>';

            // Redirect to categorywise post page after successful deletion
            header("refresh:3; url=categorypost.php"); // Redirect after 3 seconds
            exit();
        } else {
            echo "Error deleting posts: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Error preparing SQL statement: " . $config->error;
    }
} else {
    // Redirect to categorywise post page if user ID or category ID is not provided
    header("location: categorypost.php");
    exit();
}

// Close database connection
$config->close();
?>
