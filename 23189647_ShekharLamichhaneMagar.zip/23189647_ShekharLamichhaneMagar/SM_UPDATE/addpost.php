<?php
session_start();
// Include sidebar/navigation
include 'sidenav.php';

// Include database connection
include_once 'config.php';

// Initialize variables to hold form data
$title = $content = $category = '';
$title_err = $content_err = $category_err = '';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate title
    if (empty(trim($_POST['Title']))) {
        $title_err = "Please enter a title.";
    } else {
        $title = trim($_POST['Title']);
    }

    // Validate content
    if (empty(trim($_POST['Content']))) {
        $content_err = "Please enter content.";
    } else {
        $content = trim($_POST['Content']);
    }

    // Validate category
    if (empty(trim($_POST['Category']))) {
        $category_err = "Please enter a category.";
    } else {
        $category = trim($_POST['Category']);
    }

    // Check input errors before inserting into database
    if (empty($title_err) && empty($content_err) && empty($category_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO posts (Title, Content, Category_id, User_id, Date) VALUES (?, ?, ?, ?, NOW())";

        if ($stmt = $config->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ssii", $param_title, $param_content, $param_category, $param_user_id);

            // Set parameters
            $param_title = $title;
            $param_content = $content;
            // Here, you would typically look up the category ID based on the entered category name.
            // For simplicity, let's assume the category names are unique and create a new category if it doesn't exist.

            // Check if the category exists
            $category_check_sql = "SELECT Category_id FROM categories WHERE Category_name = ?";
            if ($category_stmt = $config->prepare($category_check_sql)) {
                $category_stmt->bind_param("s", $category);
                $category_stmt->execute();
                $category_stmt->store_result();

                if ($category_stmt->num_rows == 0) {
                    // Category does not exist, create a new one
                    $category_insert_sql = "INSERT INTO categories (Category_name) VALUES (?)";
                    if ($category_insert_stmt = $config->prepare($category_insert_sql)) {
                        $category_insert_stmt->bind_param("s", $category);
                        $category_insert_stmt->execute();
                        $param_category = $category_insert_stmt->insert_id; // Get the new category ID
                        $category_insert_stmt->close();
                    }
                } else {
                    // Category exists, get the category ID
                    $category_stmt->bind_result($param_category);
                    $category_stmt->fetch();
                }
                $category_stmt->close();
            }

            // User ID from session or authentication mechanism
            $param_user_id = $_SESSION['user_data']['User_id']; // Assuming User ID from session

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Success message
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        Post added successfully!
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>';

                // Redirect to admin post page after successful creation
                header("refresh:3; url=adminpost.php"); // Redirect after 3 seconds
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        } else {
            echo "Error preparing SQL statement: " . $config->error;
        }
    }

    // Close connection
    $config->close();
}
?>

<!-- HTML form for adding a post -->
<div class="content">
    <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <div class="container-fluid">
            <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
            <h2 class="header-text mb-4 text-center">Add New Post</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="row mt-4">
                    <div class="col-md-8 offset-md-2">
                        <!-- Title -->
                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="Title" class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" value="<?php echo htmlspecialchars($title); ?>">
                            <span class="invalid-feedback"><?php echo $title_err; ?></span>
                        </div>
                        <!-- Content -->
                        <div class="form-group">
                            <label>Content</label>
                            <textarea name="Content" class="form-control <?php echo (!empty($content_err)) ? 'is-invalid' : ''; ?>" rows="5"><?php echo htmlspecialchars($content); ?></textarea>
                            <span class="invalid-feedback"><?php echo $content_err; ?></span>
                        </div>
                        <!-- Category -->
                        <div class="form-group">
                            <label>Category</label>
                            <input type="text" name="Category" class="form-control <?php echo (!empty($category_err)) ? 'is-invalid' : ''; ?>" value="<?php echo htmlspecialchars($category); ?>">
                            <span class="invalid-feedback"><?php echo $category_err; ?></span>
                        </div>
                        <!-- Submit Button -->
                        <div class="form-group text-center mt-4">
                            <input type="submit" class="btn btn-primary" value="Add Post">
                            <a href="adminpost.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
