<?php
include 'sidenav.php'; // Include sidebar

// Include your database connection file
include_once 'config.php';

?>

<!-- Page content -->
<div class="content">
    <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <div class="row align-items-center">
            <div class="container-fluid">
                <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
                <h2 class="header-text mb-4 text-center">Manage Posts</h2>
                <div class="row mt-4">
                    <div class="col-md-10">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Search posts..."
                                aria-label="Search posts" aria-describedby="button-addon2">
                            <button class="btn btn-primary" type="submit" id="button-addon2"
                                style="background: #5271ff;"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a href="addpost.php">
                            <div class="input-group mb-3">
                                <button class="btn btn-primary w-100" type="button" id="button-addon2"
                                    style="background: #5271ff;">Add Post</button>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <h5 class="mb-4">Enlisted Posts:</h5>
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">SN</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Content</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch posts from the database
                                    $sql = "SELECT * FROM posts ORDER BY Post_id DESC"; // Assuming Post_id is your AUTO_INCREMENT primary key
                                    $result = $config->query($sql);

                                    $sn = 1; // Initialize serial number

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . $sn++ . "</td>";
                                            echo "<td>" . $row["Title"] . "</td>";
                                            echo "<td>" . $row["Content"] . "</td>";
                                            echo "<td>" . $row["User_id"] . "</td>"; // Assuming User_id is the author
                                            echo "<td>" . $row["Date"] . "</td>"; // Assuming Date is the date
                                            echo "<td>"; // Actions cell
                                            // Update button
                                            echo "<a href='updatepost.php?id=" . $row["Post_id"] . "' class='btn btn-primary'><i class='bi bi-pencil-square'></i> Update</a>";
                                            echo "&nbsp;&nbsp;";
                                            // Delete button
                                            echo "<a href='deletepost.php?id=" . $row["Post_id"] . "' class='btn btn-danger' onclick='return confirmDelete();'><i class='bi bi-trash'></i> Delete</a>";
                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='7'>No posts found</td></tr>";
                                    }

                                    // Close the database connection
                                    $config->close();
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this post?");
    }
</script>
</body>

</html>
