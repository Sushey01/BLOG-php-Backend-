<?php
// Include necessary files
include 'nav.php'; // Include navigation bar
include_once 'config.php'; // Include your database connection file

// Initialize variables
$post_id = ''; // Initialize post ID variable
$User_id = ''; // Assuming the user ID is obtained from session or login
$Category_name = '';
$Title = '';
$Content = '';

// Check if post_id is provided in the URL
if (isset($_GET['post_id'])) {
    $post_id = mysqli_real_escape_string($config, $_GET['post_id']);

    // Fetch post details from the database
    $post_query = "SELECT * FROM posts WHERE Post_id = '$post_id'";
    $post_result = $config->query($post_query);

    if ($post_result->num_rows > 0) {
        $post = $post_result->fetch_assoc();
        $User_id = $post['User_id']; // Assuming this is fetched from session or login
        $Category_name = htmlspecialchars($post['Category_name']);
        $Title = htmlspecialchars($post['Title']);
        $Content = htmlspecialchars($post['Content']);
    } else {
        echo "<p>Post not found.</p>";
        exit;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data to prevent SQL injection
    $post_id = mysqli_real_escape_string($config, $_POST['post_id']);
    $Category_name = mysqli_real_escape_string($config, $_POST['Category_name']);
    $Title = mysqli_real_escape_string($config, $_POST['Title']);
    $Content = mysqli_real_escape_string($config, $_POST['Content']);

    // Ensure that the post fields are not empty
    if (!empty($User_id) && !empty($Category_name) && !empty($Title) && !empty($Content)) {
        // Update post in the database
        $update_post_query = "UPDATE posts SET Category_name = '$Category_name', Title = '$Title', Content = '$Content' WHERE Post_id = '$post_id'";

        if ($config->query($update_post_query) === TRUE) {
            echo "<script>alert('Post updated successfully'); window.location='categorypost.php';</script>";
        } else {
            echo "Error updating post: " . $config->error;
        }
    } else {
        echo "<script>alert('All fields are required'); window.location='usereditpost.php?post_id=$post_id';</script>";
    }
}

// Close connection
$config->close();
?>

<!-- HTML form for editing post -->
<div class="container ">
    <div class="row justify-content-center mt-4">
        <div class="col-md-8">
            <div class="card mt-4">
                <div class="card-body mt-4">
                    <form id="postForm" method="POST">
                        <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
                        <div class="mb-3 mt-4">
                            <label for="Category_name" class="form-label">Category Name</label>
                            <input type="text" class="form-control" id="Category_name" name="Category_name" value="<?php echo $Category_name; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="Title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="Title" name="Title" value="<?php echo $Title; ?>">
                        </div>

                        <div class="mb-3">
                            <label for="Content" class="form-label">Content</label>
                            <textarea class="form-control" id="Content" name="Content" rows="5"><?php echo $Content; ?></textarea>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-primary">Update Post</button>
                            <a href="categorypost.php" class="btn btn-secondary ms-2">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
