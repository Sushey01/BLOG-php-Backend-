<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./asset/admin/dashboard.css">
</head>
<body>

<!-- Side navigation -->
<div class="sidenav">
    <a href="admindashboard.php"><i class="bi bi-house-fill"></i><span> Home</span></a>
    <a href="admincategories.php"><i class="bi bi-tags-fill"></i><span> Categories</span></a>
    <a href="adminuser.php"><i class="bi bi-people-fill"></i><span> Users</span></a>
    <a href="adminpost.php"><i class="bi bi-people-fill"></i><span> Posts</span></a>
    <a href="index.php"><i class="bi bi-box-arrow-left"></i><span> LogOut</span></a>
</div>