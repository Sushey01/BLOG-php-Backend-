<?php
// Include database connection
include_once 'config.php';

// Check if post ID is provided in the URL
if(isset($_GET['id'])) {
    $post_id = $_GET['id'];

    // Prepare SQL statement to delete post
    $sql = "DELETE FROM posts WHERE Post_id = ?";

    if ($stmt = $config->prepare($sql)) {
        // Bind the parameter
        $stmt->bind_param("i", $post_id); // Use $post_id instead of $Post_id

        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            // Debug message for successful deletion
            echo "Post with ID $post_id deleted successfully.";

            // Redirect to categorywise post page after successful deletion
            header("location: adminpost.php");
            exit();
        } else {
            // Display an error message if deletion fails
            echo "Error deleting post: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        // Display an error message if SQL preparation fails
        echo "Error preparing SQL statement: " . $config->error;
    }
} else {
    // Redirect to categorywise post page if post ID is not provided
    header("location: categorywisepost.php");
    exit();
}

// Close database connection
$config->close();
?>
