<?php
// Include database connection
include_once 'config.php';

// Check if category ID is provided in the URL
if(isset($_GET['id'])) {
    $category_id = $_GET['id'];

    // Prepare SQL statement to delete the category
    $delete_category_sql = "DELETE FROM categories WHERE Category_id = ? LIMIT 1";

    // Use prepared statement for deletion
    $stmt = $config->prepare($delete_category_sql);
    $stmt->bind_param("i", $category_id);

    // Attempt to execute the prepared statement
    if ($stmt->execute()) {
        // Debug message for successful deletion
        echo "Category with ID $category_id deleted successfully.";

        // Redirect to admincategories.php after successful deletion
        header("location: admincategories.php");
        exit();
    } else {
        // Display an error message if deletion fails
        echo "Error deleting category: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
} else {
    // Redirect to admincategories.php if category ID is not provided
    header("location: admincategories.php");
    exit();
}

// Close database connection
$config->close();
?>
