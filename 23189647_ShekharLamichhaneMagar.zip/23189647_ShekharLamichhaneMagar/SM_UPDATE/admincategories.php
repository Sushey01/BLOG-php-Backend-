<?php
// Include necessary files
include 'sidenav.php'; // Include sidebar
include_once 'config.php'; // Include database configuration

?>

<!-- Page content -->
<div class="content">
    <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <div class="container-fluid">
            <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
            <h2 class="header-text mb-4 text-center">Manage Categories</h2>
            <div class="row mt-4">
                <div class="col-md-10">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Search for categories..." aria-label="Search for categories" aria-describedby="button-addon2">
                        <button class="btn btn-primary" type="submit" id="button-addon2" style="background: #5271ff;"><i class="bi bi-search"></i></button>
                    </div>
                </div>
                <div class="col-md-2">
                    <a href="./addcategories.php">
                        <div class="input-group mb-3">
                            <button class="btn btn-primary w-100" type="button" id="button-addon2" style="background: #5271ff;">Add Category</button>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <h5 class="mb-4">Available Categories:</h5>
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">SN</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Category Description</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch categories from the database
                            $sql = "SELECT Category_id, Category_name, Category_Description FROM categories";
                            $result = $config->query($sql);

                            // Initialize serial number counter
                            $sn = 1;

                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $sn++ . "</td>"; // Increment SN for each row
                                echo "<td>" . htmlspecialchars($row["Category_name"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["Category_Description"]) . "</td>";
                                echo "<td>"; // Actions cell
                                // Update button
                                echo "<a href='updatecategory.php?id=" . $row["Category_id"] . "' class='btn btn-primary'><i class='bi bi-pencil-square'></i> Update</a>";
                                echo "&nbsp;";
                                // Delete button
                                echo "<a href='deletecategory.php?id=" . $row["Category_id"] . "' class='btn btn-danger' onclick='return confirmDelete();'><i class='bi bi-trash'></i> Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }

                            // Close the database connection
                            $config->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this category?");
    }
</script>
</body>
</html>
