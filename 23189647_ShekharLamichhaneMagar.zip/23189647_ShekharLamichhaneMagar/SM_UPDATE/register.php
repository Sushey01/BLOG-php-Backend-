<?php
include 'config.php'; // Include your database connection file

// Start session to handle session variables
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $firstName = $_POST['inputFirstName'];
    $lastName = $_POST['inputLastName'];
    $username = $_POST['inputUsername'];
    $email = $_POST['inputEmail'];
    $password = $_POST['inputPassword'];
    $confirmPassword = $_POST['inputConfirmPassword'];

    // Check if the user already exists in the database
    $check_query = "SELECT * FROM users WHERE Email = ?";
    $stmt = $config->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User already exists
        echo '<script>alert("You are already registered."); window.location.href = "login.php";</script>';
    } else {
        // Check if passwords match only for new users
        if ($password !== $confirmPassword) {
            echo '<script>alert("Passwords do not match. Please try again."); window.location.href = "register.php";</script>';
            exit(); // Stop further execution
        }

        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Insert into database for new users
        $insert_query = "INSERT INTO users (first_name, last_name, User_name, Email, Password, Role)
                         VALUES (?, ?, ?, ?, ?, 'user')";
        $stmt = $config->prepare($insert_query);
        $stmt->bind_param("sssss", $firstName, $lastName, $username, $email, $hashedPassword);

        if ($stmt->execute() === TRUE) {
            // Registration successful, redirect to login.php
            echo '<script>alert("Registration successful. Please login."); window.location.href = "login.php";</script>';
            exit();
        } else {
            // Error in SQL query
            echo "Error: " . $insert_query . "<br>" . $config->error;
        }
    }

    $stmt->close();
    $config->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SMUPDATE</title>

    <!-- Bootstrap css-->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />

    <!-- Bootstrap Icons-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link href="./asset/style.css" rel="stylesheet">
</head>
<body>
    <!-- Main Container -->
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <!-- Register Container -->
           <div class="row border rounded-5 p-3 bg-white shadow box-area">
        <!-- Left Box -->
           <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box" style="background: grey;">
               <div class="featured-image mb-3">
                <img src="./asset/images/register.png" class="img-fluid" style="width: 400px;">
               </div>
               <p class="text-white fs-2" style="font-family: 'Courier New', Courier, monospace; font-weight: 600;">Join our psychopath gang!</p>
               <small class="text-white text-wrap text-center" style="width: 17rem;font-family: 'Courier New', Courier, monospace;">To get updates of today's world!</small>
           </div> 
        <!-- Right Box -->
        <div class="col-md-6 right-box">
              <div class="row align-items-center">
                <div class="header-text mb-4 text-center">
                <h2>Register Now</h2>
                <p>Let's update the world</p>
                </div>
                <form id="registrationForm" class="row g-3" method="POST">
                  <div class="col-md-6">
                      <label for="inputFirstName" class="form-label">First Name</label>
                      <input type="text" class="form-control" id="inputFirstName" name="inputFirstName" required>
                  </div>
                  <div class="col-md-6">
                      <label for="inputLastName" class="form-label">Last Name</label>
                      <input type="text" class="form-control" id="inputLastName" name="inputLastName" required>
                  </div>
                  <div class="col-md-6">
                      <label for="inputUsername" class="form-label">Username</label>
                      <input type="text" class="form-control" id="inputUsername" name="inputUsername" required>
                  </div>
                  <div class="col-md-6">
                      <label for="inputEmail" class="form-label">Email</label>
                      <input type="email" class="form-control" id="inputEmail" name="inputEmail" required>
                  </div>
                  <div class="col-md-6">
                      <label for="inputPassword" class="form-label">Password</label>
                      <input type="password" class="form-control" id="inputPassword" name="inputPassword" required>
                  </div>
                  <div class="col-md-6">
                      <label for="inputConfirmPassword" class="form-label">Confirm Password</label>
                      <input type="password" class="form-control" id="inputConfirmPassword" name="inputConfirmPassword" required>
                  </div>
                  <div class="input-group mb-3">
                      <button type="submit" class="btn btn-lg btn-primary w-100 fs-6" style="background: #5271ff;">Register</button>
                  </div>
              </form>    
              </div>
          </div>
        </div>
    </div>
    
 <!-- Bootstrap js-->
 <script
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
 integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
 crossorigin="anonymous"
></script>   
</body>
</html>
