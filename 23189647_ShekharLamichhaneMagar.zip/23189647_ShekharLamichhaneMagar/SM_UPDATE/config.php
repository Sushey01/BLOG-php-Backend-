<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "23189647";

// Create connection
$config = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$config) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

