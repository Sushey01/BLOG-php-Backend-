<?php
// Include necessary files
include 'nav.php'; // Include navigation bar
include_once 'config.php'; // Include your database connection file

// Initialize variables
$User_id = ''; // Assuming the user ID is obtained from session or login
$Category_id = ''; // Variable to hold the Category_id
$Title = '';
$Content = '';
$image_uploaded = false;
$image = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data to prevent SQL injection
    $User_id = mysqli_real_escape_string($config, $_POST['User_id']); // Assuming user ID is obtained from session or login
    $Category_name = mysqli_real_escape_string($config, $_POST['Category_name']);
    $Category_description = mysqli_real_escape_string($config, $_POST['Category_description']); // Added category description field
    $Title = mysqli_real_escape_string($config, $_POST['Title']);
    $Content = mysqli_real_escape_string($config, $_POST['Content']);
    $image_uploaded = false;
    $image = '';

    // Handle image upload separately
    if (isset($_FILES['PostImage']) && $_FILES['PostImage']['error'] == 0) {
        $target_dir = $_SERVER['DOCUMENT_ROOT'] . '/SM_UPDATE/asset/images/';

        // Ensure the target directory exists
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $image = time() . '_' . basename($_FILES['PostImage']['name']);
        $target_file = $target_dir . $image;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check file size (2MB limit)
        if ($_FILES['PostImage']['size'] > 2000000) {
            echo "<script>alert('Image file size must not exceed 2MB'); window.location='useraddpost.php';</script>";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "<script>alert('Only JPG, JPEG, and PNG files are allowed'); window.location='useraddpost.php';</script>";
            exit;
        }

        // Try to move the uploaded file to the server
        if (move_uploaded_file($_FILES['PostImage']['tmp_name'], $target_file)) {
            $image_uploaded = true;
        } else {
            $error_message = 'Error details: ';
            switch ($_FILES['PostImage']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    $error_message .= 'The uploaded file exceeds the upload_max_filesize directive in php.ini.';
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $error_message .= 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $error_message .= 'The uploaded file was only partially uploaded.';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error_message .= 'No file was uploaded.';
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $error_message .= 'Missing a temporary folder.';
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $error_message .= 'Failed to write file to disk.';
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $error_message .= 'File upload stopped by extension.';
                    break;
                default:
                    $error_message .= 'Unknown upload error.';
                    break;
            }
            echo "<script>alert('Sorry, there was an error uploading your file. $error_message'); window.location='useraddpost.php';</script>";
            exit;
        }
    }

    // Ensure that the post fields are not empty
    if (!empty($User_id) && !empty($Category_name) && !empty($Category_description) && !empty($Title) && !empty($Content)) {
        // Check if the category already exists in admin categories
        $check_category_query = "SELECT * FROM categories WHERE Category_name = '$Category_name'";
        $check_category_result = $config->query($check_category_query);

        if ($check_category_result->num_rows > 0) {
            // Category exists, retrieve its Category_id
            $row = $check_category_result->fetch_assoc();
            $Category_id = $row['Category_id'];
        } else {
            // Category does not exist, insert it with description
            $insert_category_query = "INSERT INTO categories (Category_name, Category_description) VALUES ('$Category_name', '$Category_description')";
            if ($config->query($insert_category_query) === TRUE) {
                $Category_id = $config->insert_id;
            } else {
                echo "Error inserting new category: " . $config->error;
                exit;
            }
        }

        // Get current timestamp
        $current_timestamp = date('Y-m-d H:i:s');

        // Construct the SQL query string for inserting the post
        $insert_post_query = "INSERT INTO posts (User_id, Category_id, Title, Content, Date";
        $insert_post_query .= $image_uploaded ? ", Post_Image" : "";
        $insert_post_query .= ") VALUES ('$User_id', '$Category_id', '$Title', '$Content', '$current_timestamp'";
        $insert_post_query .= $image_uploaded ? ", '$image'" : "";
        $insert_post_query .= ")";

        // Execute the query to insert post
        if ($config->query($insert_post_query) === TRUE) {
            echo "<script>alert('Post added successfully'); window.location='categorypost.php';</script>";
        } else {
            echo "Error: " . $insert_post_query . "<br>" . $config->error;
        }
    } else {
        echo "<script>alert('All fields are required'); window.location='useraddpost.php';</script>";
    }
}

// Close connection
$config->close();
?>

<!-- HTML content for the form -->
<?php include 'nav.php'; ?>

<!-- Page content -->
<div class="content">
    <!-- Main Container -->
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <!-- Registration Container -->
        <div class="row border rounded-5 p-3 bg-white shadow box-area">
            <div class="row align-items-center">
                <div class="header-text mb-4 text-center">
                    <h2>Add Post</h2>
                </div>
                <form id="postForm" class="row align-items-center" method="POST" enctype="multipart/form-data">
                    <div class="col-md-12 mb-3 mt-2">
                        <label for="User_id" class="form-label">User ID</label>
                        <input type="text" class="form-control" id="User_id" name="User_id" placeholder="Enter User ID">
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="Category_name" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="Category_name" name="Category_name" placeholder="Enter Category Name">
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="Category_description" class="form-label">Category Description</label>
                        <textarea class="form-control" id="Category_description" name="Category_description" rows="3" placeholder="Enter Category Description"></textarea>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="Title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="Title" name="Title" placeholder="Enter Post Title">
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="Content" class="form-label">Content</label>
                        <textarea class="form-control" id="Content" name="Content" rows="3" placeholder="Enter Post Content"></textarea>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="PostImage" class="form-label">Post Image</label>
                        <input type="file" class="form-control" id="PostImage" name="PostImage">
                    </div>

                    <div class="col-md-6 mx-auto mb-3">
                        <button type="submit" class="btn btn-lg btn-primary w-100 fs-6" style="background: #5271ff;">Add Post</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
