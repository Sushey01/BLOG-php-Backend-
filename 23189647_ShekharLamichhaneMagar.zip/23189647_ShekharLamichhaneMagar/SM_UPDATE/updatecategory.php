<?php
// Include database configuration
include_once 'config.php';

// Initialize variables
$current_name = '';
$current_description = '';
$category_id = '';

// Check if category ID is provided in the URL
if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    // Fetch category data from the database based on the provided category ID
    $sql = "SELECT Category_name, Category_Description FROM categories WHERE Category_id = ?";
    
    if ($stmt = $config->prepare($sql)) {
        $stmt->bind_param("i", $category_id);
        
        if ($stmt->execute()) {
            $stmt->store_result();
            
            if ($stmt->num_rows == 1) {
                $stmt->bind_result($current_name, $current_description);
                $stmt->fetch();
            } else {
                echo "<script>alert('Category not found'); window.location='admincategories.php';</script>";
                exit();
            }
        } else {
            echo "Error executing SQL statement: " . $stmt->error;
        }
        
        // Close statement
        $stmt->close();
    } else {
        echo "Error preparing SQL statement: " . $config->error;
    }
}

// Process form submission when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_category_name = $_POST['categoryName'];
    $new_category_description = $_POST['categoryDescription'];
    $category_id = $_POST['category_id'];

    // Update category in the database
    $update_query = "UPDATE categories SET Category_name = ?, Category_Description = ? WHERE Category_id = ?";
    
    if ($stmt = $config->prepare($update_query)) {
        $stmt->bind_param("ssi", $new_category_name, $new_category_description, $category_id);
        
        if ($stmt->execute()) {
            // Redirect to admin categories page with success message
            header("Location: admincategories.php?message=Category updated successfully.");
            exit();
        } else {
            echo "Error updating category: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Error preparing SQL statement: " . $config->error;
    }
}

// Close the database connection
$config->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Category</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <?php include 'sidenav.php'; ?>

    <!-- Page content -->
    <div class="content">
        <!-- Main Container -->
        <div class="container d-flex justify-content-center align-items-center min-vh-100">
            <!-- Update Category Container -->   
            <div class="row border rounded-5 p-3 bg-white shadow box-area">
                <div class="row align-items-center">
                    <div class="header-text mb-4 text-center">
                        <h2>Update Category</h2>
                    </div>
                    <form id="categoryForm" class="row align-items-center" method="POST">
                        <div class="col-md-12 mb-3">
                            <label for="categoryName" class="form-label">Category Name</label>
                            <input type="text" class="form-control" id="categoryName" name="categoryName" value="<?php echo htmlspecialchars($current_name); ?>" required>
                        </div>
        
                        <div class="col-md-12 mb-3">
                            <label for="categoryDescription" class="form-label">Category Description</label>
                            <textarea class="form-control" id="categoryDescription" name="categoryDescription" rows="3" required><?php echo htmlspecialchars($current_description); ?></textarea>
                        </div>
        
                        <div class="col-md-6 mx-auto mb-3">
                            <button type="submit" class="btn btn-lg btn-primary w-100 fs-6" style="background: #5271ff;">Update Category</button>
                        </div>
        
                        <input type="hidden" name="category_id" value="<?php echo htmlspecialchars($category_id); ?>">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
