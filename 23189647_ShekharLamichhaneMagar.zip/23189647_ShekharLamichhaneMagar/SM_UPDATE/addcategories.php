<?php
// Include the database connection file
include 'config.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $categoryName = $_POST['categoryName'];
    $categoryDescription = $_POST['categoryDescription'];

    // Check if the category name already exists
    $check_query = "SELECT * FROM categories WHERE Category_Name = '$categoryName'";
    $result = $config->query($check_query);

    if ($result->num_rows > 0) {
        // Category name already exists
        echo "<script>alert('Category name already exists. Please choose a different name.'); window.location='addcategories.html';</script>";
    } else {
        // Ensure that the category name and description are not empty
        if (!empty($categoryName) && !empty($categoryDescription)) {
            // Construct the SQL query string
            $sinsert_query = "INSERT INTO categories (Category_Name, Category_Description) VALUES ('$categoryName', '$categoryDescription')";

            // Execute the query
            if ($config->query($sinsert_query) === TRUE) {
                echo "<script>alert('Category added successfully'); window.location='admincategories.php';</script>";
            } else {
                echo "Error: " . $sinsert_query . "<br>" . $config->error;
            }
        } else {
            echo "<script>alert('Category name and description cannot be empty'); window.location='addcategories.html';</script>";
        }
    }
}

// Close connection
$config->close();
?>
<?php
include 'sidenav.php';
?>
<!-- Page content -->
<div class="content">
    <!-- Main Container -->
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <!-- Registration Container -->   
        <div class="row border rounded-5 p-3 bg-white shadow box-area">
            <div class="row align-items-center">
                <div class="header-text mb-4 text-center">
                    <h2>Add Category</h2>
                </div>
                <form id="categoryForm" class="row align-items-center" method="POST">
                    <div class="col-md-12 mb-3">
                        <label for="categoryName" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="categoryName" name="categoryName" placeholder="Enter Category Name">
                    </div>
    
                    <div class="col-md-12 mb-3">
                        <label for="categoryDescription" class="form-label">Category Description</label>
                        <textarea class="form-control" id="categoryDescription" name="categoryDescription" rows="3" placeholder="Enter Category Description"></textarea>
                    </div>
    
                    <div class="col-md-6 mx-auto mb-3">
                        <button  type="submit" class="btn btn-lg btn-primary w-100 fs-6" style="background: #5271ff;">Add Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
