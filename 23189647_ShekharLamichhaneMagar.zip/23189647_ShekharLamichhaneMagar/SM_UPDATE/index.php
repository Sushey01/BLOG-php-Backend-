<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_name'])) {
    $welcome_message = "Welcome, " . $_SESSION['user_name'] . "!";
} else {
    $welcome_message = "Welcome! Here we get every update of the world.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SM_UPDATE</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="./asset/style.css" rel="stylesheet">
    <link href="./asset/index.css" rel="stylesheet">
</head>
<body>

<?php include 'nav.php'; ?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container text-center">
        <h1><?php echo $welcome_message; ?></h1>
    </div>
</section>
<!-- Hero Section -->

<!-- About Us Section -->
<section id="about-us" class="about-us-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="display-4 text-center">Me as a Student</h2>
                <p class="lead">My name is Shekhar Lamichhane Magar, and I am currently pursuing a Bachelor's degree in Computer and Data Science, now in my second year. I am passionate about exploring the intersections of computer science and data analytics to solve real-world problems efficiently. Beyond academics, I enjoy staying updated with the latest technological advancements and engaging in hands-on projects that enhance my skills. I believe in continuous learning and applying my knowledge to contribute meaningfully to the field of technology.</p>
                <p class="text-center ">"The pressure to make the right decisions about your future can be overwhelming."</p>
            </div>
        </div>
    </div>
</section>
<!-- About Us Section -->

<?php include 'footer.php'; ?>

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
