<?php
    include 'sidenav.php';
?>

<!-- Page content -->
<div class="content">
    <a class="navbar-brand me-auto" href="#"><img src="./asset/images/logo.png"></a>
    <p>Welcome to the admin dashboard.</p>
</div>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
