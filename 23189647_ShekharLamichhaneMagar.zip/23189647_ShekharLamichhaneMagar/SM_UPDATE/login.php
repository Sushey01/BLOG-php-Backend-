<?php
session_start();
include 'config.php';
include 'nav.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate inputs
    $email = mysqli_real_escape_string($config, $_POST['email']);
    $password = mysqli_real_escape_string($config, $_POST['password']);

    // Check if the admin is logging in
    if ($email == 'shekhar@gmail.com' && $password == '1234') {
        $_SESSION['user_data'] = [
            'User_name' => 'Admin',
            'Role' => 'admin'
        ];
        header("Location: admindashboard.php");
        exit();
    }

    // For regular users, proceed with normal login
    $hashedPassword = sha1($password); // Use appropriate hashing method (replace with bcrypt or better)

    $sql = "SELECT * FROM users WHERE email='{$email}' AND password='{$hashedPassword}'";
    $query = mysqli_query($config, $sql);

    if ($query && mysqli_num_rows($query) > 0) {
        $user = mysqli_fetch_assoc($query);
        $_SESSION['user_data'] = [
            'User_id' => $user['User_id'],
            'User_name' => $user['User_name'],
            'Role' => 'user' // Assuming all users are regular users
        ];
        header("Location: index.php?user_id=" . $user['User_id']);
        exit();
    } else {
        $_SESSION['error'] = "Login failed. Check your credentials or register.";
        header("Location: register.php");
        exit();
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-xl-6 offset-md-4 m-auto p-5 mt-5 bg-info">
            <form action="" method="POST">
                <p class="text-center">Login to your account.</p>
                <div class="mb-3">
                    <input type="email" name="email" placeholder="Email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <input type="password" name="password" placeholder="Password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <input type="submit" name="login_btn" class="btn btn-primary" value="Login">
                </div>
                <?php
                if (isset($_SESSION['error'])) {
                    $error = $_SESSION['error'];
                    echo "<p class='bg-danger p-2 text-white'>" . $error . "</p>";
                    unset($_SESSION['error']);
                }
                ?>
            </form>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>

